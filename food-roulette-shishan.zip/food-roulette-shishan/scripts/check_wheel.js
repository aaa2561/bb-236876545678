#!/usr/bin/env node
/**
 * 转盘自检脚本 —— 「屎山可以，跑不动不行」
 *
 * 用法：
 *   node check_wheel.js <path/to/food-roulette.html>
 *
 * 检查项：
 *   1. 单文件自足（无外部 http(s) 依赖、无 <script src>、无 <link href> 外链）
 *   2. JS 语法可解析（new Function）
 *   3. CSS 大括号平衡
 *   4. 关键 DOM id 全部存在（缺一个 UI 就会静默失灵）
 *   5. 菜库数量、口味覆盖度（每个口味至少 8 道）
 *   6. 转盘几何不变量：内定赢家 == 指针停下的格子（5000 次蒙特卡洛）
 *
 * 退出码：0 = 全部通过，1 = 有失败项
 */
const fs = require("fs");
const path = require("path");

const file = process.argv[2];
if (!file) {
  console.error("用法: node check_wheel.js <food-roulette.html>");
  process.exit(2);
}
if (!fs.existsSync(file)) {
  console.error("找不到文件: " + file);
  process.exit(2);
}

const html = fs.readFileSync(file, "utf8");
const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: detail || "" });
}

/* --- 1. 单文件自足 --- */
const extScript = /<script[^>]+src=/i.test(html);
const extLink = /<link[^>]+href=["']https?:/i.test(html);
const extHttp = /(src|href)=["']https?:\/\//i.test(html);
check("无外链脚本/样式（离线可运行）", !extScript && !extLink && !extHttp,
  extScript ? "发现 <script src>" : extLink || extHttp ? "发现外链资源" : "纯内联，40KB 以内即可离线跑");

/* --- 2. JS 语法 --- */
const mScript = html.match(/<script>([\s\S]*?)<\/script>/);
let jsOk = false, jsErr = "";
if (!mScript) jsErr = "找不到 <script> 块";
else {
  try { new Function(mScript[1]); jsOk = true; } catch (e) { jsErr = e.message; }
}
check("JS 语法可解析", jsOk, jsErr || (mScript[1].split("\n").length + " 行"));

/* --- 3. CSS 平衡 --- */
const mCss = html.match(/<style>([\s\S]*?)<\/style>/);
let bal = 0;
if (mCss) for (const c of mCss[1]) { if (c === "{") bal++; if (c === "}") bal--; }
check("CSS 大括号平衡", bal === 0, bal === 0 ? "平衡" : "差 " + bal + " 个");

/* --- 4. 关键 id --- */
const ids = ["wheel", "hub", "result", "history", "chips", "confetti", "toast",
  "poolCount", "dbCount", "customInput", "btnCustom", "customList",
  "optAvoid", "optSound", "optConfetti", "optLock", "btnClearHist"];
const missing = ids.filter((id) => !new RegExp('id="' + id + '"').test(html));
check("关键 DOM 节点齐全", missing.length === 0, missing.length ? "缺少: " + missing.join(", ") : ids.length + " 个节点齐全");

/* --- 5. 菜库与口味覆盖 --- */
let foods = [];
const mFoods = html.match(/var\s+FOODS_源数据\s*=\s*(\[[\s\S]*?\n\];)/);
if (mFoods) {
  try { foods = new Function("return " + mFoods[1])(); } catch (e) { foods = []; }
}
check("菜库 ≥ 20 道", foods.length >= 20, foods.length + " 道");
const flavors = ["酸", "甜", "辣", "咸"];
const cover = flavors.map((f) => f + ":" + foods.filter((x) => (x.t || []).indexOf(f) >= 0).length).join("  ");
const thin = flavors.filter((f) => foods.filter((x) => (x.t || []).indexOf(f) >= 0).length < 8);
check("每个口味 ≥ 8 道可选", foods.length > 0 && thin.length === 0, cover + (thin.length ? "  偏少: " + thin.join(",") : ""));
const noEmoji = foods.filter((x) => !x.e).length;
check("每道菜都有 emoji 图形提醒", foods.length > 0 && noEmoji === 0, noEmoji ? noEmoji + " 道缺 emoji" : "全部有 emoji");

/* --- 6. 几何不变量：指针 == 赢家 --- */
function norm(a) { const P = Math.PI * 2; return ((a % P) + P) % P; }
let bad = 0, shortSpin = 0;
for (let r = 0; r < 5000; r++) {
  const n = 2 + Math.floor(Math.random() * 11);
  const seg = (Math.PI * 2) / n, twoPi = Math.PI * 2;
  const winIdx = Math.floor(Math.random() * n);
  const start = Math.random() * 100;
  const mid = (winIdx + 0.5) * seg;
  const base = -Math.PI / 2 - mid;
  const turns = 6 + Math.floor(Math.random() * 3);
  const need = start + turns * twoPi;
  const k = Math.ceil((need - base) / twoPi) + 1;
  const jitter = (Math.random() - 0.5) * seg * 0.62;
  const target = base + k * twoPi + jitter;
  if (Math.floor(norm(-Math.PI / 2 - target) / seg) !== winIdx) bad++;
  if (target < start + turns * twoPi) shortSpin++;
}
check("指针与结果 100% 一致（5000 次模拟）", bad === 0, bad === 0 ? "0 次不一致" : bad + " 次不一致");
check("圈数只多不少（不会转半圈就停）", shortSpin === 0, shortSpin === 0 ? "最少 6 圈" : shortSpin + " 次不足");

/* --- 打印报告 --- */
console.log("\n⛰️  屎山转盘自检报告 —— " + path.basename(file));
console.log("   " + "-".repeat(56));
let fail = 0;
for (const r of results) {
  if (!r.ok) fail++;
  console.log("   " + (r.ok ? "✅" : "❌") + " " + r.name.padEnd(30, " ") + " " + r.detail);
}
console.log("   " + "-".repeat(56));
console.log(fail === 0
  ? "   🎉 全部通过：可以交付（屎山依旧能跑，这就是它的浪漫）\n"
  : "   ⚠️  有 " + fail + " 项失败，修好再交付\n");
process.exit(fail === 0 ? 0 : 1);
